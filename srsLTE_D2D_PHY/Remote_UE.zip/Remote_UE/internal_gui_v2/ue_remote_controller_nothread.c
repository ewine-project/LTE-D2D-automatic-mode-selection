#include<stdio.h>
#include<stdlib.h>
#include<gtk/gtk.h>
//file for socket implementation
#include"client.h"
#include"pthread.h"
GtkBuilder *builder;
GObject *window;
GObject *downlinkButton;
GObject *sidelinkButton;

//sidelink
GObject *restartButton_sl;
GtkSpinButton *spinButton_sl;
GtkEntry *gainText_sl;
GObject *prbText_sl;
GObject *rntiText_sl;
GtkRadioButton *ghzRadio_sl;
GtkRadioButton *mhzRadio_sl;
GList *radioGroup_sl;
GObject *portText_sl;
GObject *connectButton_sl;

/*
pthread_t thread_downlink_bash;
pthread_t thread_sidelink_bash;
*/  

//functions for sidelink

static void restart_sl(GtkWidget *widget,gpointer data){
  char socket_data[100];
  printf("\nrestarting\n");
  //print formatted output to array
  sprintf(socket_data,"restart:%d\0",1);
  //send array through socket
  socket_send(socket_data);
}

static void open_port_sl(GtkWidget *widget, gpointer textEntry){
  char socket_data[100];
  int port=atoi(gtk_entry_get_text(textEntry));
  printf("\nopening port %d\n",port);
  //print formatted output to array
  client_init(port);
}

static void  toggl_sl(GtkRadioButton *widget, int* data){
  //Checks which radio button was pressed (GHz or MHz)
  if(gtk_toggle_button_get_active (widget)){
    *data = 1000000000;
    printf("frequency_multiplier=%d\n",*data );
  }else{
    *data = 1000000;
    printf("frequency_multiplier=%d\n",*data );
  }
}

static void  changeFrequency_sl(GtkSpinButton *spin_button_sl , int *   data){
  //adjustment to retrive the value from spin button
  GtkAdjustment *adjustment;
  //get adjustment object from spin button
  adjustment = gtk_spin_button_get_adjustment (spin_button_sl);
  float value=200;
  value = (float)gtk_adjustment_get_value (adjustment);
  //multiply the value from spin button with the base 10^6 or 10^9
  value=value*(*data);
  char socket_data[100];
  sprintf(socket_data,"frequency:%.2f\0",value);
  socket_send(socket_data);
  printf("Frequency changed, the USRP will be restarted\n");
}


static void  set_gain_sl(GtkEntry *obj, gpointer entry){
  int gain=atoi(gtk_entry_get_text(obj));
  char socket_data[100];
  printf("\nChange in gain to %d requested\n",gain);
  sprintf(socket_data,"gain:%d\0",gain);
  socket_send(socket_data);
}

static void  gtk_set_prbs_sl(GtkWidget *obj, gpointer entry){
  int nof_prbs=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange in number of PRBs requested %d\n",nof_prbs);
  sprintf(socket_data,"prbs:%d\0",nof_prbs);
  socket_send(socket_data);
}

static void  gtk_set_RNTI_sl(GtkWidget *obj, gpointer  entry){
  //rnti is input in the text box as hexadecimal
  int rnti = strtol(gtk_entry_get_text(entry), NULL, 16);
  char socket_data[100];
  printf("\nChange of RNTI requested 0x%4X\n",rnti);
  sprintf(socket_data,"rnti:%d\0",rnti);
  socket_send(socket_data);
}
/*
void downlink_bash()
{
int status1 = system("killall pdsch_ue_new");
int status = system("exec /home/nodeuser/srslte_sidelink/build/srslte/examples/pdsch_ue_new -f 2500000000 -r 1234 -k 12345");
}

void sidelink_bash()
{
int status1_sl = system("killall pssch_rx_new");
int status_sl = system("exec /home/nodeuser/srslte_sidelink/build/srslte/examples/pssch_rx_new -f 2560000000 -r 1234 -k 12345");
}
*/

static void sidelink(GtkWidget *widget,gpointer data){

//pthread_create( &thread_sidelink_bash, NULL , sidelink_bash, NULL);
//freq multiplier 10^6 or 10^9
int frequency_multiplier=1000000000;

//inits gtk, program arguments could be passed instead of NULL
gtk_init (NULL, NULL);
//builder for importing buttons and other widgets from .ui file
builder = gtk_builder_new ();
//opens the gtkbuilder file created with glade
gtk_builder_add_from_file (builder, "ue_remote_gui_sl.ui", NULL);

window = gtk_builder_get_object (builder, "window");
//g_signal_connect links a signal to a handler function
g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);
//creates spinbutton object for sidelink
spinButton_sl = gtk_builder_get_object (builder, "freqSpinbutton");
//sets initial value, limits and step for the spinbutton
GtkAdjustment *adj_sl = gtk_adjustment_new (2.400, 0,8, 0.01, 0, 1);
gtk_spin_button_set_adjustment (spinButton_sl, adj_sl);
g_signal_connect(spinButton_sl,"value-changed",G_CALLBACK(changeFrequency_sl),&frequency_multiplier);

//text entry object for sidelink
gainText_sl = GTK_WIDGET(gtk_builder_get_object(builder,"gainEntry"));
g_signal_connect (gainText_sl, "activate", G_CALLBACK (set_gain_sl), gainText_sl);

//text entry object for sidelink
prbText_sl = gtk_builder_get_object(builder,"prbsEntry");
g_signal_connect(prbText_sl,"activate",G_CALLBACK(gtk_set_prbs_sl),prbText_sl);

//text entry
rntiText_sl=gtk_builder_get_object(builder,"rntiEntry");
g_signal_connect(rntiText_sl,"activate",G_CALLBACK(gtk_set_RNTI_sl),rntiText_sl);

//radiobutton group, for GHz or MHz selection object for sidelink
mhzRadio_sl = gtk_builder_get_object(builder,"radiobutton4");
ghzRadio_sl = gtk_builder_get_object(builder,"radiobutton3");
//starts with GHz set active
gtk_toggle_button_set_active (ghzRadio_sl,TRUE);
radioGroup_sl = gtk_radio_button_get_group (ghzRadio_sl);
gtk_radio_button_set_group (mhzRadio_sl,radioGroup_sl);
g_signal_connect(ghzRadio_sl,"toggled",G_CALLBACK(toggl_sl),&frequency_multiplier);

//restart button object for sidelink
restartButton_sl = gtk_builder_get_object(builder,"button3");
g_signal_connect(restartButton_sl,"clicked",G_CALLBACK(restart_sl),NULL);

//text entry object for port for sidelink
portText_sl = gtk_builder_get_object(builder,"entry20");
//socket opening button object for sidelink
connectButton_sl = gtk_builder_get_object(builder,"button4");
g_signal_connect(connectButton_sl,"clicked",G_CALLBACK(open_port_sl),portText_sl);
gtk_main ();
}

//objects for downlink
GObject *restartButton;
GObject *label;
GtkSpinButton *spinButton;
GtkEntry *gainText;
GObject *prbText;
GObject *rntiText;
GObject *cellIDText;
GtkRadioButton *ghzRadio;
GtkRadioButton *mhzRadio;
GList *radioGroup;
GObject *portText;
GObject *connectButton;

//downlink
static void restart(GtkWidget *widget,gpointer data){
  char socket_data[100];
  printf("\nrestarting\n");
  //print formatted output to array
  sprintf(socket_data,"restart:%d\0",1);
  //send array through socket
  socket_send(socket_data);
}

static void open_port(GtkWidget *widget, gpointer textEntry){
  char socket_data[100];
  int port=atoi(gtk_entry_get_text(textEntry));
  printf("\nopening port %d\n",port);
  //print formatted output to array
  client_init(port);
}

static void  toggl(GtkRadioButton *widget, int* data){
  //Checks which radio button was pressed (GHz or MHz)
  if(gtk_toggle_button_get_active (widget)){
    *data = 1000000000;
    printf("frequency_multiplier=%d\n",*data );
  }else{
    *data = 1000000;
    printf("frequency_multiplier=%d\n",*data );
  }
}

static void  changeFrequency(GtkSpinButton *spin_button , int *   data){
  //adjustment to retrive the value from spin button
  GtkAdjustment *adjustment;
  //get adjustment object from spin button
  adjustment = gtk_spin_button_get_adjustment (spin_button);
  float value=200;
  value = (float)gtk_adjustment_get_value (adjustment);
  //multiply the value from spin button with the base 10^6 or 10^9
  value=value*(*data);
  char socket_data[100];
  sprintf(socket_data,"frequency:%.2f\0",value);
  socket_send(socket_data);
  printf("Frequency changed, the USRP will be restarted\n");
}


static void  set_gain(GtkEntry *obj, gpointer entry){
  int gain=atoi(gtk_entry_get_text(obj));
  char socket_data[100];
  printf("\nChange in gain to %d requested\n",gain);
  sprintf(socket_data,"gain:%d\0",gain);
  socket_send(socket_data);
}

static void  gtk_set_prbs(GtkWidget *obj, gpointer entry){
  int nof_prbs=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange in number of PRBs requested %d\n",nof_prbs);
  sprintf(socket_data,"prbs:%d\0",nof_prbs);
  socket_send(socket_data);
}

static void  gtk_set_RNTI(GtkWidget *obj, gpointer  entry){
  //rnti is input in the text box as hexadecimal
  int rnti = strtol(gtk_entry_get_text(entry), NULL, 16);
  char socket_data[100];
  printf("\nChange of RNTI requested 0x%4X\n",rnti);
  sprintf(socket_data,"rnti:%d\0",rnti);
  socket_send(socket_data);
}

static void  gtk_set_new_cell_ID(GtkWidget *obj, gpointer entry){
  int id=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange of cell ID requested %d\n",id);
  sprintf(socket_data,"cell:%d\0",id);
  socket_send(socket_data);
}



static void downlink(GtkWidget *widget,gpointer data){
//pthread_create( &thread_downlink_bash, NULL , downlink_bash, NULL);
//freq multiplier 10^6 or 10^9
int frequency_multiplier=1000000000;
//inits gtk, program arguments could be passed instead of NULL
gtk_init (NULL, NULL);
//builder for importing buttons and other widgets from .ui file
builder = gtk_builder_new ();
//opens the gtkbuilder file created with glade
gtk_builder_add_from_file (builder, "ue_remote_gui_dl.ui", NULL);

window = gtk_builder_get_object (builder, "window1");
//g_signal_connect links a signal to a handler function
g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);

//creates spinbutton object for downlkink
spinButton=gtk_builder_get_object (builder, "spinbutton1");
//sets initial value, limits and step for the spinbutton
GtkAdjustment *adj = gtk_adjustment_new (1.830, 0,8, 0.01, 0, 1);
gtk_spin_button_set_adjustment (spinButton, adj);
g_signal_connect(spinButton,"value-changed",G_CALLBACK(changeFrequency),&frequency_multiplier);

//text entry object for downlink
gainText=GTK_WIDGET(gtk_builder_get_object(builder,"entry1"));
g_signal_connect (gainText, "activate", G_CALLBACK (set_gain), gainText);

//text entry object for downlink
prbText=gtk_builder_get_object(builder,"entry2");
g_signal_connect(prbText,"activate",G_CALLBACK(gtk_set_prbs),prbText);

//text entry object for downlink
rntiText=gtk_builder_get_object(builder,"entry3");
g_signal_connect(rntiText,"activate",G_CALLBACK(gtk_set_RNTI),rntiText);

//text entry object for downlink
cellIDText=gtk_builder_get_object(builder,"entry4");
g_signal_connect(cellIDText,"activate",G_CALLBACK(gtk_set_new_cell_ID),cellIDText);

//radiobutton group, for GHz or MHz selection object for downlink
mhzRadio=gtk_builder_get_object(builder,"radiobutton2");
ghzRadio=gtk_builder_get_object(builder,"radiobutton1");
//starts with GHz set active
gtk_toggle_button_set_active (ghzRadio,TRUE);
radioGroup = gtk_radio_button_get_group (ghzRadio);
gtk_radio_button_set_group (mhzRadio,radioGroup);
g_signal_connect(ghzRadio,"toggled",G_CALLBACK(toggl),&frequency_multiplier);

//restart button object for downlink
restartButton=gtk_builder_get_object(builder,"button1");
g_signal_connect(restartButton,"clicked",G_CALLBACK(restart),NULL);

portText=gtk_builder_get_object(builder,"entry5");
//socket opening button object for downlink
connectButton=gtk_builder_get_object(builder,"button2");
g_signal_connect(connectButton,"clicked",G_CALLBACK(open_port),portText);
gtk_main ();


}



void main(int argc, char *argv[]){
//inits gtk, program arguments could be passed instead of NULL
gtk_init (NULL, NULL);
//builder for importing buttons and other widgets from .ui file
builder = gtk_builder_new ();
//opens the gtkbuilder file created with glade
gtk_builder_add_from_file (builder, "ue_remote_controller_gui1.ui", NULL);

//window
window = gtk_builder_get_object (builder, "window1");
//g_signal_connect links a signal to a handler function
g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);

//downlink button
downlinkButton = gtk_builder_get_object(builder,"button2");
g_signal_connect(downlinkButton,"clicked",G_CALLBACK (downlink),NULL);

//sidelink button
sidelinkButton = gtk_builder_get_object(builder,"button1");
g_signal_connect(sidelinkButton,"clicked",G_CALLBACK (sidelink),NULL);

gtk_main ();
}
