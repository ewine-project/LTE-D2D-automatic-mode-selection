#ifndef CLIENT_H
#define CLIENT_H
#define hostname "ctvr-Precision-M2800"
//#define port "272"

extern void error(const char*);
extern void client_init(int port);
extern void socket_send(char*);
extern void socket_read();
extern int socket_close();

#endif
