/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
//ROBSON: Code adapted from http://www.linuxhowtos.org/C_C++/socket.htm

#include "server.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
int sockfd, newsockfd, portno;
socklen_t clilen;
char buffer[256];
struct sockaddr_in serv_addr, cli_addr;
int n;

void error(const char *msg)
{
    perror(msg);
    exit(1);
}

extern void server_init(int port){
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     printf("\nopening socket on %d\n",port);

     if (sockfd < 0)
        error("ERROR opening socket");
    int enable = 1;
    //ROBSON: functions for reusing sockets
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
        error("setsockopt(SO_REUSEADDR) failed");
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, &enable, sizeof(int)) < 0)
        error("setsockopt(SO_REUSEPORT) failed");

     bzero((char *) &serv_addr, sizeof(serv_addr));
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(port);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0)
              error("ERROR on binding");
     listen(sockfd,5);
     clilen = sizeof(cli_addr);
     newsockfd = accept(sockfd,
                 (struct sockaddr *) &cli_addr,
                 &clilen);
     if (newsockfd < 0)
          error("ERROR on accept");
}
//ROBSON: Reads a message to a buffer
extern char* socket_read(char * buff){
     bzero(buff,256);
     n = read(newsockfd,buff,255);
     if (n < 0) error("ERROR reading from socket");
     return buffer;
}
//ROBSON: Writes a message to socket
extern void socket_write(char * buff){
     n = write(newsockfd,buff,strlen(buff));
     if (n < 0) error("ERROR writing to socket");
}
//ROBSON: closes socket
extern void socket_close(){
  close(newsockfd);
  close(sockfd);
}
