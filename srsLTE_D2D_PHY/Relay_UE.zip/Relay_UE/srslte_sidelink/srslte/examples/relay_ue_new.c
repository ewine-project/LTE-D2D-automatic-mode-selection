/**
 *
 * \section COPYRIGHT
 *
 * Copyright 2013-2015 Software Radio Systems Limited
 *
 * \section LICENSE
 *
 * This file is part of the srsLTE library.
 *
 * srsLTE is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of
 * the License, or (at your option) any later version.
 *
 * srsLTE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * A copy of the GNU Affero General Public License can be found in
 * the LICENSE file in the top-level directory of this distribution
 * and at http://www.gnu.org/licenses/.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <math.h>
#include <sys/time.h>
#include <unistd.h>
#include <assert.h>
#include <signal.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/select.h>//from sidelink

//ROBSON added a file for socket communication
#include "server.h"
//ROBSON end of adding socket file

#include "srslte/srslte.h"

#define ENABLE_AGC_DEFAULT
//#define DISABLE_GRAPHICS


#ifndef DISABLE_RF
#include "srslte/rf/rf.h"
#include "srslte/rf/rf_utils.h"
srslte_rf_t rf_sl;
cell_search_cfg_t cell_detect_config = {
  SRSLTE_DEFAULT_MAX_FRAMES_PBCH,
  SRSLTE_DEFAULT_MAX_FRAMES_PSS,
  SRSLTE_DEFAULT_NOF_VALID_PSS_FRAMES,
  0
};
#else
#warning Compiling pdsch_ue with no RF support
#endif

////declarations of sidelink
//ROBSON: Added the variable restart, this variable controls
//the inner loop, when it goes true the station is reconfigured



#define DATA_BUFF_SZ    1024*128
uint8_t data_sl[8*DATA_BUFF_SZ], data2[DATA_BUFF_SZ];
uint8_t data_tmp[DATA_BUFF_SZ];
//uint8_t data_relay_temp[8*DATA_BUFF_SZ];


bool go_exit_sl = false;
bool restart_sl= false;

void sig_int_handler_sl(int signo)
{
  printf("SIGINT received. Exiting...\n");
  if (signo == SIGINT) {
    //ROBSON: When the user interrupts the program, restart
    //also goes true to interrupt the inner loop and go_exit to interrupt
    //the external loop
    restart_sl = true;
    go_exit_sl = true;
  }
}

#define UE_CRNTI 0x1234

char *output_file_name = NULL;

#define LEFT_KEY  68
#define RIGHT_KEY 67
#define UP_KEY    65
#define DOWN_KEY  66

srslte_cell_t cell_sl = {
  25,            // nof_prb
  1,            // nof_ports
  0,            // bw idx
  0,            // cell_id
  SRSLTE_CP_NORM,       // cyclic prefix
  SRSLTE_PHICH_R_1,          // PHICH resources
  SRSLTE_PHICH_NORM    // PHICH length
};

int net_port = -1; // -1 generates random dataThat means there is some problem sending samples to the device
int portnumber_sl=0; //port for GUI socket

uint32_t cfi=3;
uint32_t mcs_idx = 1, last_mcs_idx = 1;
int nof_frames = -1;

char *rf_sl_args = "";
float rf_sl_amp = 0.8, rf_sl_gain = 70.0, rf_sl_freq = 2400000000;

bool null_file_sink=false;
srslte_filesink_t fsink;
srslte_ofdm_t ifft;
srslte_pbch_t pbch;
srslte_pcfich_t pcfich;
srslte_pdcch_t pdcch;
srslte_pdsch_t pssch;
srslte_pdsch_cfg_t pssch_cfg;
srslte_softbuffer_tx_t softbuffer;
srslte_regs_t regs;
srslte_ra_dl_dci_t ra_dl;

cf_t *output_buffer = NULL;
int sf_n_re, sf_n_samples;

pthread_t net_thread;
void *net_thread_fnc(void *arg);
sem_t net_sem;
bool net_packet_ready = false;
srslte_netsource_t net_source;

///YI-shekhar: need to check net_sink variable when transmitting video
srslte_netsink_t net_sink_sl;
///////////end of

int prbset_num = 1, last_prbset_num = 1;
int prbset_orig = 0;
////end of declarations



//ROBSON: port number for socket, received as an argumment later
int portnumber;
//ROBSON: end of port number define

//pulled out variables from downlink main
int ret;
srslte_cell_t cell;
int64_t sf_cnt;
srslte_ue_mib_t ue_mib;
// end


//#define STDOUT_COMPACT


#ifndef DISABLE_GRAPHICS
#include "srsgui/srsgui.h"
void init_plots();
pthread_t plot_thread;
sem_t plot_sem;
uint32_t plot_sf_idx=0;
bool plot_track = true;
#endif


#define PRINT_CHANGE_SCHEDULIGN

//#define CORRECT_SAMPLE_OFFSET

/**********************************************************************
 *  Program arguments processing
 ***********************************************************************/
typedef struct {
  int nof_subframes;
  bool disable_plots;
  bool disable_plots_except_constellation;
  bool disable_cfo;
  uint32_t time_offset;
  int force_N_id_2;
  uint16_t rnti;
  char *input_file_name;
  int file_offset_time;
  float file_offset_freq;
  uint32_t file_nof_prb;
  uint32_t file_nof_ports;
  uint32_t file_cell_id;
  char *rf_args;
  double rf_freq;
  float rf_gain;
  int net_port;
  char *net_address;
  int net_port_signal;
  char *net_address_signal;
}prog_args_t;

void args_default(prog_args_t *args) {
  args->disable_plots = false;
  args->disable_plots_except_constellation = false;
  args->nof_subframes = -1;
  args->rnti = SRSLTE_SIRNTI;
  args->force_N_id_2 = -1; // Pick the best
  args->input_file_name = NULL;
  args->disable_cfo = false;
  args->time_offset = 0;
  args->file_nof_prb = 25;
  args->file_nof_ports = 1;
  args->file_cell_id = 0;
  args->file_offset_time = 0;
  args->file_offset_freq = 0;
  args->rf_args = "";
  args->rf_freq = -1.0;
#ifdef ENABLE_AGC_DEFAULT
  args->rf_gain = -1.0;
#else
  args->rf_gain = 50.0;
#endif
  args->net_port = -1;
  args->net_address = "127.0.0.1";
  args->net_port_signal = -1;
  args->net_address_signal = "127.0.0.1";
}

void usage(prog_args_t *args, char *prog) {
  printf("Usage: %s [agpPoOcildDnruv] -f rx_frequency (in Hz) | -i input_file\n", prog);
#ifndef DISABLE_RF
  printf("\t-a RF args [Default %s]\n", args->rf_args);
#ifdef ENABLE_AGC_DEFAULT
  printf("\t-g RF fix RX gain [Default AGC]\n");
#else
  printf("\t-g Set RX gain [Default %.1f dB]\n", args->rf_gain);
#endif
#else
  printf("\t   RF is disabled.\n");
#endif
  printf("\t-i input_file [Default use RF board]\n");
  printf("\t-o offset frequency correction (in Hz) for input file [Default %.1f Hz]\n", args->file_offset_freq);
  printf("\t-O offset samples for input file [Default %d]\n", args->file_offset_time);
  printf("\t-p nof_prb for input file [Default %d]\n", args->file_nof_prb);
  printf("\t-P nof_ports for input file [Default %d]\n", args->file_nof_ports);
  printf("\t-c cell_id for input file [Default %d]\n", args->file_cell_id);
  printf("\t-r RNTI in Hex [Default 0x%x]\n",args->rnti);
  printf("\t-l Force N_id_2 [Default best]\n");
  printf("\t-C Disable CFO correction [Default %s]\n", args->disable_cfo?"Disabled":"Enabled");
  printf("\t-t Add time offset [Default %d]\n", args->time_offset);
#ifndef DISABLE_GRAPHICS
  printf("\t-d disable plots [Default enabled]\n");
  printf("\t-D disable all but constellation plots [Default enabled]\n");
#else
  printf("\t plots are disabled. Graphics library not available\n");
#endif
  printf("\t-n nof_subframes [Default %d]\n", args->nof_subframes);
  printf("\t-s remote UDP port to send input signal (-1 does nothing with it) [Default %d]\n", args->net_port_signal);
  printf("\t-S remote UDP address to send input signal [Default %s]\n", args->net_address_signal);
  printf("\t-u remote TCP port to send data (-1 does nothing with it) [Default %d]\n", args->net_port);
  printf("\t-U remote TCP address to send data [Default %s]\n", args->net_address);
  printf("\t-v [set srslte_verbose to debug, default none]\n");


printf("Usage: %s [123456789zxy]\n", prog);
#ifndef DISABLE_RF
  printf("\t-1 RF args [Default %s]\n", rf_sl_args);
  printf("\t-3 RF amplitude [Default %.2f]\n", rf_sl_amp);
  printf("\t-2 RF TX gain [Default %.2f dB]\n", rf_sl_gain);
  printf("\t-4 RF TX frequency [Default %.1f MHz]\n", rf_sl_freq / 1000000);
#else
  printf("\t   RF is disabled.\n");
#endif
  printf("\t-5 output_file [Default use RF board]\n");
  printf("\t-6 MCS index [Default %d]\n", mcs_idx);
  printf("\t-8 number of frames [Default %d]\n", nof_frames);
  printf("\t-z master UE id [Default %d]\n", cell_sl.id);
  printf("\t-9 nof_prb [Default %d]\n", cell_sl.nof_prb);
  printf("\t-7 listen TCP port for input data (-1 is random) [Default %d]\n", net_port);
  printf("\t-x [set srslte_verbose to debug, default none]\n");
  printf("\t-y port number for linking the GUI\n");
}

//ROBSON:Added argumment for port number
void parse_args(prog_args_t *args, int argc, char **argv) {
  int opt;
  args_default(args);
  while ((opt = getopt(argc, argv, "aoglipPcOCtdDnvrfuUsSk123456789zxy")) != -1) {
    switch (opt) {
    case 'i':
      args->input_file_name = argv[optind];
      break;
    case 'p':
      args->file_nof_prb = atoi(argv[optind]);
      break;
    case 'P':
      args->file_nof_ports = atoi(argv[optind]);
      break;
    case 'o':
      args->file_offset_freq = atof(argv[optind]);
      break;
    case 'O':
      args->file_offset_time = atoi(argv[optind]);
      break;
    case 'c':
      args->file_cell_id = atoi(argv[optind]);
      break;
    case 'a':
      args->rf_args = argv[optind];
      break;
    case 'g':
      args->rf_gain = atof(argv[optind]);
      break;
    case 'C':
      args->disable_cfo = true;
      break;
    case 't':
      args->time_offset = atoi(argv[optind]);
      break;
    case 'f':
      args->rf_freq = strtod(argv[optind], NULL);
      break;
    case 'n':
      args->nof_subframes = atoi(argv[optind]);
      break;
    case 'r':
      args->rnti = strtol(argv[optind], NULL, 16);
      break;
    case 'l':
      args->force_N_id_2 = atoi(argv[optind]);
      break;
    case 'u':
      args->net_port = atoi(argv[optind]);
      break;
    case 'U':
      args->net_address = argv[optind];
      break;
    case 's':
      args->net_port_signal = atoi(argv[optind]);
      break;
    case 'S':
      args->net_address_signal = argv[optind];
      break;
    case 'd':
      args->disable_plots = true;
      break;
    case 'D':
      args->disable_plots_except_constellation = true;
      break;
    case 'v':
      srslte_verbose++;
      break;
    case 'k'://ROBSON: argumment for port number
      portnumber=atoi(argv[optind]);
      break;
    case '1':
      rf_sl_args = argv[optind];
      break;
    case '2':
      rf_sl_gain = atof(argv[optind]);
      break;
    case '3':
      rf_sl_amp = atof(argv[optind]);
      break;
    case '4':
      rf_sl_freq = atof(argv[optind]);
      break;
    case '5':
      output_file_name = argv[optind];
      break;
    case '6':
      mcs_idx = atoi(argv[optind]);
      break;
    case '7':
      net_port = atoi(argv[optind]);
      break;
    case '8':
      nof_frames = atoi(argv[optind]);
      break;
    case '9':
      cell_sl.nof_prb = atoi(argv[optind]);
      break;
    case 'z':
      cell_sl.id = atoi(argv[optind]);
      break;
    case 'x':
      srslte_verbose++;
      break;
    case 'y':
      portnumber_sl=atoi(argv[optind]);
      break;
    default:
      usage(args, argv[0]);
      exit(-1);
    }
  }
  if (args->rf_freq < 0 && args->input_file_name == NULL) {
    usage(args, argv[0]);
    exit(-1);
  }

#ifdef DISABLE_RF
  if (!output_file_name) {
    usage(args,argv[0]);
    exit(-1);
  }
#endif
}
/**********************************************************************/

/* TODO: Do something with the output data */
uint8_t data[8*DATA_BUFF_SZ];

//ROBSON: added restart and srsGUIstarted
bool go_exit = false;
//changed when the user passes an parameter that needs the cell to be seached again
bool restart = false;
//avoids the srsGUI init function to be called more than once
bool srsGUIstarted=false;

//hello
void sig_int_handler(int signo)
{
  printf("SIGINT received. Exiting...\n");
  if (signo == SIGINT) {
    //ROBSON: case a program interrupt is received, restart is changed in order
    //to cancel the inner program loop
    restart = true;
    go_exit = true;
  }
}

#ifndef DISABLE_RF
int srslte_rf_recv_wrapper(void *h, void *data, uint32_t nsamples, srslte_timestamp_t *t) {
  DEBUG(" ----  Receive %d samples  ---- \n", nsamples);
  return srslte_rf_recv(h, data, nsamples, 1);
}

double srslte_rf_set_rx_gain_th_wrapper_(void *h, double f) {
  return srslte_rf_set_rx_gain_th((srslte_rf_t*) h, f);
}

#endif

extern float mean_exec_time;

enum receiver_state { DECODE_MIB, DECODE_PDSCH} state;

srslte_ue_dl_t ue_dl;
srslte_ue_sync_t ue_sync;
prog_args_t prog_args;

uint32_t sfn = 0; // system frame number
cf_t *sf_buffer = NULL;
cf_t *sf_buffer_sl = NULL;
srslte_netsink_t net_sink, net_sink_signal;

//ROBSON rf moved here so it is visible by the thread
#ifndef DISABLE_RF
  srslte_rf_t rf;
#endif
//ROBSON end of modification

void *socket_thread_fctn(void *threadid){
  server_init(portnumber);
  char buff[256];
  char value[20];
  while(1){
    bzero(value,20);
    bzero(buff,256);
    socket_read(buff);

    char *clnptr=strchr(buff,':' )+1;

    if((strstr(buff,"frequency"))){
      printf("\nFound value for freq\n");
      strcpy(value, clnptr);
      prog_args.rf_freq=atof(value);
      restart=true;
    }


    if((strstr(buff,"gain"))){
      printf("\nFound value for gain\n");
      strcpy(value, clnptr);
      prog_args.rf_gain=atof(value);
      srslte_rf_set_rx_gain(&rf, prog_args.rf_gain);

    }
    if((strstr(buff,"prbs"))){
      printf("\nFound value for prbs\n");
      strcpy(value, clnptr);
      prog_args.file_nof_prb=atoi(value);
      restart=true;
    }
    if((strstr(buff,"cell"))){
      printf("\nFound value for cell\n");
      strcpy(value, clnptr);
      prog_args.file_cell_id=atoi(value);
      restart=true;
    }
    if((strstr(buff,"restart"))){
      restart=true;
    }
    //printf("value:%s, pointer %d\n",value,clnptr);
  }
}


void *socket_thread_fctn_sl(){
  printf("\nOpening socket\n");
  server_init(portnumber_sl);
  char buff[256];
  char value[20];
  while(1){
    bzero(buff,256);
    bzero(value,20);

    socket_read(buff);
    printf("\nmessage: %s\n",buff );
    printf("\nPTR: %d\n", strstr(buff,"frequency"));

    char *clnptr=strchr(buff,':' )+1;

    if((strstr(buff,"frequency"))){
      printf("Found value for freq\n");
      strcpy(value, clnptr);
      rf_sl_freq=atof(value);
      restart_sl=true;
    }
    if((strstr(buff,"gain"))){
      printf("Found value for gain\n");
      strcpy(value, clnptr);
      rf_sl_gain=atof(value);
      printf("Set TX gain: %.1f dB\n", srslte_rf_set_tx_gain(&rf_sl, rf_sl_gain));
    }
    if((strstr(buff,"prbs"))){
      printf("Found value for prbs\n");
      strcpy(value, clnptr);
      cell_sl.nof_prb = atoi(value);
      printf("\nok\n");
      restart_sl=true;
    }
    if((strstr(buff,"cell"))){
      printf("Found value for cell\n");
      strcpy(value, clnptr);
      cell_sl.id=atoi(value);
      restart_sl=true;
    }
    if((strstr(buff,"amp"))){
      printf("Found value for amplitude\n");
      strcpy(value, clnptr);
      rf_sl_amp=atof(value);
      restart_sl=true;
    }
    if((strstr(buff,"mcs"))){
      printf("Found value for MCS\n");
      strcpy(value, clnptr);
      mcs_idx=atoi(value);
      update_radl();

    }
    if((strstr(buff,"restart"))){
      restart_sl=true;
    }
    printf("value:%s, pointer %d\n",value,clnptr);
  }
}





void loop_downlink(){

 while(!go_exit){
    pthread_t thread_for;
    pthread_t new_thread_for_downlink;
    //ROBSON: resets the restart parameter, so the inner loop can run again
    restart=false;
    restart_sl=false;
    //ROBSON: just continues pdsch_ue code
    uint32_t nof_trials = 0;
    int n;
    uint8_t bch_payload[SRSLTE_BCH_PAYLOAD_LEN];
    int sfn_offset;
    float cfo = 0;

    if (prog_args.net_port > 0) {
      if (srslte_netsink_init(&net_sink, prog_args.net_address, prog_args.net_port, SRSLTE_NETSINK_TCP)) {
        fprintf(stderr, "Error initiating UDP socket to %s:%d\n", prog_args.net_address, prog_args.net_port);
        exit(-1);
      }
      srslte_netsink_set_nonblocking(&net_sink);
    }
    if (prog_args.net_port_signal > 0) {
      if (srslte_netsink_init(&net_sink_signal, prog_args.net_address_signal,
        prog_args.net_port_signal, SRSLTE_NETSINK_UDP)) {
        fprintf(stderr, "Error initiating UDP socket to %s:%d\n", prog_args.net_address_signal, prog_args.net_port_signal);
        exit(-1);
      }
      srslte_netsink_set_nonblocking(&net_sink_signal);
    }

  #ifndef DISABLE_RF
    if (!prog_args.input_file_name) {


      printf("Opening RF device...\n");
      if (srslte_rf_open(&rf, prog_args.rf_args)) {
        fprintf(stderr, "Error opening rf\n");
        exit(-1);
      }

      /* Set receiver gain */
      if (prog_args.rf_gain > 0) {
        srslte_rf_set_rx_gain(&rf, prog_args.rf_gain);
      } else {
        printf("Starting AGC thread...\n");
        if (srslte_rf_start_gain_thread(&rf, false)) {
          fprintf(stderr, "Error opening rf\n");
          exit(-1);
        }
        srslte_rf_set_rx_gain(&rf, 50);
        cell_detect_config.init_agc = 50;
      }

      sigset_t sigset;
      sigemptyset(&sigset);
      sigaddset(&sigset, SIGINT);
      sigprocmask(SIG_UNBLOCK, &sigset, NULL);
      signal(SIGINT, sig_int_handler);

      srslte_rf_set_master_clock_rate(&rf, 30.72e6);

      /* set receiver frequency */
      printf("Tunning receiver to %.3f MHz\n", prog_args.rf_freq/1000000);
      srslte_rf_set_rx_freq(&rf, prog_args.rf_freq);
      srslte_rf_rx_wait_lo_locked(&rf);

      uint32_t ntrial=0;
      do {
        ret = rf_search_and_decode_mib(&rf, &cell_detect_config, prog_args.force_N_id_2, &cell, &cfo);
        if (ret < 0) {
          fprintf(stderr, "Error searching for cell\n");
          exit(-1);
        } else if (ret == 0 && !restart) {
          printf("Cell not found after %d trials. Trying again (Press Ctrl+C to exit)\n", ntrial++);
        }
      } while (ret == 0 && !restart);

      }
      if (!restart) {
        /* set sampling frequency */
        int srate = srslte_sampling_freq_hz(cell.nof_prb);
        if (srate != -1) {
          if (srate < 10e6) {
            srslte_rf_set_master_clock_rate(&rf, 4*srate);
          } else {
            srslte_rf_set_master_clock_rate(&rf, srate);
          }
          printf("Setting sampling rate %.2f MHz\n", (float) srate/1000000);
          float srate_rf = srslte_rf_set_rx_srate(&rf, (double) srate);
          if (srate_rf != srate) {
            fprintf(stderr, "Could not set sampling rate\n");
            exit(-1);
          }
        } else {
          fprintf(stderr, "Invalid number of PRB %d\n", cell.nof_prb);
          exit(-1);
        }

        INFO("Stopping RF and flushing buffer...\r",0);
        srslte_rf_stop_rx_stream(&rf);
        srslte_rf_flush_buffer(&rf);

        #endif

        /* If reading from file, go straight to PDSCH decoding. Otherwise, decode MIB first */
        if (prog_args.input_file_name) {
        /* preset cell configuration */
        cell.id = prog_args.file_cell_id;
        cell.cp = SRSLTE_CP_NORM;
        cell.phich_length = SRSLTE_PHICH_NORM;
        cell.phich_resources = SRSLTE_PHICH_R_1;
        cell.nof_ports = prog_args.file_nof_ports;
        cell.nof_prb = prog_args.file_nof_prb;

        if (srslte_ue_sync_init_file(&ue_sync, prog_args.file_nof_prb,
          prog_args.input_file_name, prog_args.file_offset_time, prog_args.file_offset_freq)) {
          fprintf(stderr, "Error initiating ue_sync\n");
          exit(-1);
        }

        } else {
        #ifndef DISABLE_RF
        if (srslte_ue_sync_init(&ue_sync, cell, srslte_rf_recv_wrapper, (void*) &rf)) {
          fprintf(stderr, "Error initiating ue_sync\n");
          exit(-1);
        }
        #endif
        }

        if (srslte_ue_mib_init(&ue_mib, cell)) {
        fprintf(stderr, "Error initaiting UE MIB decoder\n");
        exit(-1);
        }

        if (srslte_ue_dl_init(&ue_dl, cell)) {  // This is the User RNTI
        fprintf(stderr, "Error initiating UE downlink processing module\n");
        exit(-1);
        }

        /* Configure downlink receiver for the SI-RNTI since will be the only one we'll use */
        srslte_ue_dl_set_rnti(&ue_dl, prog_args.rnti);

        /* Initialize subframe counter */
        sf_cnt = 0;


        #ifndef DISABLE_GRAPHICS
        if (!prog_args.disable_plots&&!srsGUIstarted) {
          init_plots(cell);
          sleep(1);
          srsGUIstarted=true;
        }
        #endif

        #ifndef DISABLE_RF
        if (!prog_args.input_file_name) {
        srslte_rf_start_rx_stream(&rf);
        }
        #endif

        // Variables for measurements
        uint32_t nframes=0;
        float rsrp=0.0, rsrq=0.0, noise=0.0;
        bool decode_pdsch = false;

        #ifndef DISABLE_RF
        if (prog_args.rf_gain < 0) {
        srslte_ue_sync_start_agc(&ue_sync, srslte_rf_set_rx_gain_th_wrapper_, cell_detect_config.init_agc);
        }
        #endif
        #ifdef PRINT_CHANGE_SCHEDULIGN
        srslte_ra_dl_dci_t old_dl_dci;
        bzero(&old_dl_dci, sizeof(srslte_ra_dl_dci_t));
        #endif

        ue_sync.correct_cfo = !prog_args.disable_cfo;

        // Set initial CFO for ue_sync
        srslte_ue_sync_set_cfo(&ue_sync, cfo);

        INFO("\nEntering main loop...\n\n", 0);
        /* Main loop */
        //ROBSON: changed go_exit to restart here
        //restart is made true in order to escape this loop, while go_exit closes the program


//ROBSON: restart goes false so that the main loop can run


  int nf=0, sf_idx=0, N_id_2=0;
  cf_t pss_signal[SRSLTE_PSS_LEN];
  float sss_signal0[SRSLTE_SSS_LEN]; // for subframe 0
  float sss_signal5[SRSLTE_SSS_LEN]; // for subframe 5
  uint8_t bch_payload_sl[SRSLTE_BCH_PAYLOAD_LEN];
  int i;
  cf_t *sf_symbols[SRSLTE_MAX_PORTS];
  cf_t *slot1_symbols[SRSLTE_MAX_PORTS];
  srslte_dci_msg_t dci_msg;
  srslte_dci_location_t locations[SRSLTE_NSUBFRAMES_X_FRAME][30];
  uint32_t sfn_sl;
  srslte_chest_dl_t est;


  N_id_2 = cell_sl.id % 3;
  sf_n_re = 2 * SRSLTE_CP_NORM_NSYMB * cell_sl.nof_prb * SRSLTE_NRE;
  sf_n_samples = 2 * SRSLTE_SLOT_LEN(srslte_symbol_sz(cell_sl.nof_prb));

  cell_sl.phich_length = SRSLTE_PHICH_NORM;
  cell_sl.phich_resources = SRSLTE_PHICH_R_1;
  sfn_sl = 0;

  prbset_num = (int) ceilf((float) cell_sl.nof_prb / srslte_ra_type0_P(cell_sl.nof_prb));
  last_prbset_num = prbset_num;

  /* this *must* be called after setting slot_len_* */
  base_init();

  /* Generate PSS/SSS signals */
  srslte_pss_generate(pss_signal, N_id_2);
  srslte_sss_generate(sss_signal0, sss_signal5, cell_sl.id);

  /* Generate CRS signals */
  if (srslte_chest_dl_init(&est, cell_sl)) {
    fprintf(stderr, "Error initializing equalizer\n");
    exit(-1);
  }

  for (i = 0; i < SRSLTE_MAX_PORTS; i++) { // now there's only 1 port
    sf_symbols[i] = sf_buffer_sl;
    slot1_symbols[i] = &sf_buffer_sl[SRSLTE_SLOT_LEN_RE(cell_sl.nof_prb, cell_sl.cp)];
  }

#ifndef DISABLE_RF

  sigset_t sigset_sl;
  sigemptyset(&sigset_sl);
  sigaddset(&sigset_sl, SIGINT);
  sigprocmask(SIG_UNBLOCK, &sigset_sl, NULL);
  signal(SIGINT, sig_int_handler_sl);


  if (!output_file_name) {

    int srate_sl = srslte_sampling_freq_hz(cell_sl.nof_prb);
    if (srate_sl != -1) {
      if (srate_sl < 10e6) {
        srslte_rf_set_master_clock_rate(&rf_sl, 4*srate_sl);
      } else {
        srslte_rf_set_master_clock_rate(&rf_sl, srate_sl);
      }
      printf("Setting sampling rate %.2f MHz\n", (float) srate_sl/1000000);
      float srate_rf_sl = srslte_rf_set_tx_srate(&rf_sl, (double) srate_sl);
      if (srate_rf_sl != srate_sl) {
        fprintf(stderr, "Could not set sampling rate\n");
        exit(-1);
      }
    } else {
      fprintf(stderr, "Invalid number of PRB %d\n", cell_sl.nof_prb);
      exit(-1);
    }
    printf("Set TX gain: %.1f dB\n", srslte_rf_set_tx_gain(&rf_sl, rf_sl_gain));
    printf("Set TX freq: %.2f MHz\n",
        srslte_rf_set_tx_freq(&rf_sl, rf_sl_freq) / 1000000);
  }
#endif

  if (update_radl(sf_idx)) {
    exit(-1);
  }

  if (net_port > 0) {
    if (pthread_create(&net_thread, NULL, net_thread_fnc, NULL)) {
      perror("pthread_create");
      exit(-1);
    }
  }

  /* Initiate valid DCI locations */
  for (i=0;i<SRSLTE_NSUBFRAMES_X_FRAME;i++) {
    srslte_pdcch_ue_locations(&pdcch, locations[i], 30, i, cfi, UE_CRNTI);

  }

  nf = 0;

  bool send_data = false;
  srslte_softbuffer_tx_reset(&softbuffer);

//////////////////////Yi: start downlink loop (with sidelink condition together in the "while"):

#ifndef DISABLE_RF
  bool start_of_burst = true;
#endif
void for_function()// new function
{
while ((nf < nof_frames || nof_frames == -1) && !restart_sl) {
for (sf_idx = 0; sf_idx < SRSLTE_NSUBFRAMES_X_FRAME && (nf < nof_frames || nof_frames == -1); sf_idx++) {
      bzero(sf_buffer_sl, sizeof(cf_t) * sf_n_re);

      if (sf_idx == 0 || sf_idx == 5) {
        srslte_pss_put_slot(pss_signal, sf_buffer_sl, cell_sl.nof_prb, SRSLTE_CP_NORM);
        srslte_sss_put_slot(sf_idx ? sss_signal5 : sss_signal0, sf_buffer_sl, cell_sl.nof_prb,
            SRSLTE_CP_NORM);
      }

      srslte_refsignal_cs_put_sf(cell_sl, 0, est.csr_signal.pilots[0][sf_idx], sf_buffer_sl);

      srslte_pbch_mib_pack(&cell_sl, sfn_sl, bch_payload_sl);
      if (sf_idx == 0) {
        srslte_pbch_encode(&pbch, bch_payload_sl, slot1_symbols, nf%4);
      }

      srslte_pcfich_encode(&pcfich, cfi, sf_symbols, sf_idx);

      /* Update DL resource allocation from control port */
      if (update_control(sf_idx)) {
        fprintf(stderr, "Error updating parameters from control port\n");
      }

      /* Transmit PSCCH + PSSCH only when there is data to send */
      if (net_port > 0) {
        send_data = net_packet_ready;
        if (net_packet_ready) {
          INFO("Transmitting packet\n",0);
        }
      } else {
        INFO("SF: %d, Generating %d random bits\n", sf_idx, pssch_cfg.grant.mcs.tbs);
        for (i=0;i<pssch_cfg.grant.mcs.tbs/8;i++) {
          data_sl[i] = rand()%256;
        }
        /* Uncomment this to transmit on sf 0 and 5 only  */

/////////////Yi: here we transmit on every sub frame.

// if (sf_idx != 1000) {
      if (sf_idx != 0 && sf_idx != 5) {
          send_data = true;
        } else {
          send_data = false;
        }
      }

      if (send_data) {

        /* Encode PDCCH */
        INFO("Putting DCI to location: n=%d, L=%d\n", locations[sf_idx][0].ncce, locations[sf_idx][0].L);
        srslte_dci_msg_pack_pdsch(&ra_dl, SRSLTE_DCI_FORMAT1, &dci_msg, cell_sl.nof_prb, false);
        if (srslte_pdcch_encode(&pdcch, &dci_msg, locations[sf_idx][0], UE_CRNTI, sf_symbols, sf_idx, cfi)) {
          fprintf(stderr, "Error encoding DCI message\n");
          exit(-1);
        }


///////////////////Yi: config pssch parameters
        /* Configure pssch_cfg parameters */
        srslte_ra_dl_grant_t grant;
        srslte_ra_dl_dci_to_grant(&ra_dl, cell_sl.nof_prb, UE_CRNTI, &grant);

        if (srslte_pssch_cfg(&pssch_cfg, cell_sl, &grant, cfi, sf_idx, 0)) {
          fprintf(stderr, "Error configuring PSSCH\n");
          exit(-1);
        }

	//printf ("PDCCH correct\n");
//////Yi: PSSCH encoding (like PUSCH), finally use PSSCH encoding because of adding directly the dft in the library.
        /* Encode PUSCH */
        if (srslte_pssch_encode(&pssch, &pssch_cfg, &softbuffer, data_sl, sf_symbols)) {
          fprintf(stderr, "Error encoding PUSCH\n");
          exit(-1);
        }

    //printf ("PSSCH correct\n");
//////////////////////////////

        if (net_port > 0 && net_packet_ready) {
          if (null_file_sink) {
            srslte_bit_pack_vector(data_sl, data_tmp, pssch_cfg.grant.mcs.tbs);
            if (srslte_netsink_write(&net_sink_sl, data_tmp, 1+(pssch_cfg.grant.mcs.tbs-1)/8) < 0) {
              fprintf(stderr, "Error sending data through UDP socket\n");
            }
          }
          net_packet_ready = false;
          sem_post(&net_sem);
        }
      }

      /* Transform to OFDM symbols */
      srslte_ofdm_tx_sf(&ifft, sf_buffer_sl, output_buffer);

      /* send to file or usrp */
      if (output_file_name) {
        if (!null_file_sink) {
          srslte_filesink_write(&fsink, output_buffer, sf_n_samples);
        }
        usleep(1000);
      } else {
#ifndef DISABLE_RF
        // FIXME
        float norm_factor = (float) cell_sl.nof_prb/15/sqrtf(pssch_cfg.grant.nof_prb);
        srslte_vec_sc_prod_cfc(output_buffer, rf_sl_amp*norm_factor, output_buffer, SRSLTE_SF_LEN_PRB(cell_sl.nof_prb));
        srslte_rf_send2(&rf_sl, output_buffer, sf_n_samples, true, start_of_burst, false);
        start_of_burst=false;
#endif
      }
   }
    nf++;
    sfn_sl = (sfn_sl + 1) % 1024;
}
}//new bracket



 void new_thread_downlink()
        {

while (!restart && (sf_cnt < prog_args.nof_subframes || prog_args.nof_subframes == -1)) {

        ret = srslte_ue_sync_get_buffer(&ue_sync, &sf_buffer);

        if (ret < 0) {
          fprintf(stderr, "Error calling srslte_ue_sync_work()\n");
        }

        #ifdef CORRECT_SAMPLE_OFFSET
        float sample_offset = (float) srslte_ue_sync_get_last_sample_offset(&ue_sync)+srslte_ue_sync_get_sfo(&ue_sync)/1000;
        srslte_ue_dl_set_sample_offset(&ue_dl, sample_offset);
        #endif

        /* srslte_ue_sync_get_buffer returns 1 if successfully read 1 aligned subframe */
        if (ret == 1) {
          switch (state) {
            case DECODE_MIB:
              if (srslte_ue_sync_get_sfidx(&ue_sync) == 0) {
                srslte_pbch_decode_reset(&ue_mib.pbch);
                n = srslte_ue_mib_decode(&ue_mib, sf_buffer, bch_payload, NULL, &sfn_offset);
                if (n < 0) {
                  fprintf(stderr, "Error decoding UE MIB\n");
                  exit(-1);
                } else if (n == SRSLTE_UE_MIB_FOUND) {
                  srslte_pbch_mib_unpack(bch_payload, &cell, &sfn);
                  srslte_cell_fprint(stdout, &cell, sfn);
                  printf("Decoded MIB. SFN: %d, offset: %d\n", sfn, sfn_offset);
                  sfn = (sfn + sfn_offset)%1024;
                  state = DECODE_PDSCH;
                }
              }
              break;
            case DECODE_PDSCH:
              if (prog_args.rnti != SRSLTE_SIRNTI) {
                decode_pdsch = true;
              } else {
                /* We are looking for SIB1 Blocks, search only in appropiate places */
                if ((srslte_ue_sync_get_sfidx(&ue_sync) == 5 && (sfn%2)==0)) {
                  decode_pdsch = true;
                } else {
                  decode_pdsch = false;
                }
              }
              if (decode_pdsch) {
                INFO("Attempting DL decode SFN=%d\n", sfn);
                n = srslte_ue_dl_decode(&ue_dl, &sf_buffer[prog_args.time_offset], data, sfn*10+srslte_ue_sync_get_sfidx(&ue_sync));
	//Yi-Shekhar: add a relay temp

                 // uint8_t *data_relay_temp_ptr= &data;
                 //   data_relay_temp_ptr = &data_relay_temp;
          //

      if (n < 0) {
                 // fprintf(stderr, "Error decoding UE DL\n");fflush(stdout);
                } else if (n > 0) {
                  /* Send data if socket active */
                  if (prog_args.net_port > 0) {
                    srslte_netsink_write(&net_sink, data, 1+(n-1)/8);
                  }

                  #ifdef PRINT_CHANGE_SCHEDULIGN
                  if (ue_dl.dl_dci.mcs_idx         != old_dl_dci.mcs_idx           ||
                      memcmp(&ue_dl.dl_dci.type0_alloc, &old_dl_dci.type0_alloc, sizeof(srslte_ra_type0_t)) ||
                      memcmp(&ue_dl.dl_dci.type1_alloc, &old_dl_dci.type1_alloc, sizeof(srslte_ra_type1_t)) ||
                      memcmp(&ue_dl.dl_dci.type2_alloc, &old_dl_dci.type2_alloc, sizeof(srslte_ra_type2_t)))
                  {
                    memcpy(&old_dl_dci, &ue_dl.dl_dci, sizeof(srslte_ra_dl_dci_t));
                    fflush(stdout);
                    printf("Format: %s\n", srslte_dci_format_string(ue_dl.dci_format));
                    srslte_ra_pdsch_fprint(stdout, &old_dl_dci, cell.nof_prb);
                    srslte_ra_dl_grant_fprint(stdout, &ue_dl.pdsch_cfg.grant);
                  }
                  #endif

                }

                nof_trials++;

                rsrq = SRSLTE_VEC_EMA(srslte_chest_dl_get_rsrq(&ue_dl.chest), rsrq, 0.1);
                rsrp = SRSLTE_VEC_EMA(srslte_chest_dl_get_rsrp(&ue_dl.chest), rsrp, 0.05);
                noise = SRSLTE_VEC_EMA(srslte_chest_dl_get_noise_estimate(&ue_dl.chest), noise, 0.05);
                nframes++;
                if (isnan(rsrq)) {
                  rsrq = 0;
                }
                if (isnan(noise)) {
                  noise = 0;
                }
                if (isnan(rsrp)) {
                  rsrp = 0;
                }
              }

              // Plot and Printf
              if (srslte_ue_sync_get_sfidx(&ue_sync) == 5) {
                float gain = prog_args.rf_gain;
                if (gain < 0) {
                  gain = 10*log10(srslte_agc_get_gain(&ue_sync.agc));
                }
                /*printf("CFO: %+6.2f kHz, "
                       "SNR: %4.1f dB,"
                       "PDCCH-Miss: %5.2f%%, PDSCH-BLER: %5.2f%%\r",

                      srslte_ue_sync_get_cfo(&ue_sync)/1000,
                      10*log10(rsrp/noise),
                      100*(1-(float) ue_dl.nof_detected/nof_trials),
                      (float) 100*ue_dl.pkt_errors/ue_dl.pkts_total);*/
                       printf("CFO: %+6.2f kHz, "
                       "SNR: %4.1f dB\r",

                      srslte_ue_sync_get_cfo(&ue_sync)/1000,
                      10*log10(rsrp/noise));
              }
              break;
          }
          if (srslte_ue_sync_get_sfidx(&ue_sync) == 9) {
            sfn++;
            if (sfn == 1024) {
              sfn = 0;
              printf("\n");
              ue_dl.pkt_errors = 0;
              ue_dl.pkts_total = 0;
              ue_dl.nof_detected = 0;
              nof_trials = 0;
            }
          }

          #ifndef DISABLE_GRAPHICS
          if (!prog_args.disable_plots) {
            if ((sfn%4) == 0 && decode_pdsch) {
              plot_sf_idx = srslte_ue_sync_get_sfidx(&ue_sync);
              plot_track = true;
              sem_post(&plot_sem);
            }
          }
          #endif
        } else if (ret == 0) {
          printf("Finding PSS... Peak: %8.1f, FrameCnt: %d, State: %d\r",
            srslte_sync_get_peak_value(&ue_sync.sfind),
            ue_sync.frame_total_cnt, ue_sync.state);
          #ifndef DISABLE_GRAPHICS
          if (!prog_args.disable_plots) {
            plot_sf_idx = srslte_ue_sync_get_sfidx(&ue_sync);
            plot_track = false;
            sem_post(&plot_sem);
          }
          #endif
        }

        sf_cnt++;

    }// end of while
} //end of downlink function





////////////////////the following is the sidelink


pthread_create(& new_thread_for_downlink, NULL , (void *)new_thread_downlink, NULL);
//pthread_join(new_thread_for_downlink,NULL);
sleep(10);
pthread_create(&thread_for, NULL , (void *)for_function, NULL);
pthread_join(thread_for,NULL);



        // Main loop

      }//ROBSON: end of if(!restart && !restart_sl)
      srslte_ue_dl_free(&ue_dl);
      srslte_ue_sync_free(&ue_sync);
      base_free();

      #ifndef DISABLE_RF
      if (!prog_args.input_file_name) {
        srslte_ue_mib_free(&ue_mib);
        srslte_rf_close(&rf);

      }
      #endif



  }//if(go_exit)




}

/*
void loop(void){

while(!go_exit_sl){
   }
}

*/
void base_init() {

  /* init memory */
  sf_buffer_sl = srslte_vec_malloc(sizeof(cf_t) * sf_n_re);
  if (!sf_buffer_sl) {
    perror("malloc");
    exit(-1);
  }
  output_buffer = srslte_vec_malloc(sizeof(cf_t) * sf_n_samples);
  if (!output_buffer) {
    perror("malloc");
    exit(-1);
  }
  /* open file or USRP */
  if (output_file_name) {
    if (strcmp(output_file_name, "NULL")) {
      if (srslte_filesink_init(&fsink, output_file_name, SRSLTE_COMPLEX_FLOAT_BIN)) {
        fprintf(stderr, "Error opening file %s\n", output_file_name);
        exit(-1);
      }
      null_file_sink = false;
    } else {
      null_file_sink = true;
    }
  } else {


#ifndef DISABLE_RF
    printf("Opening RF device...\n");

    if (srslte_rf_open(&rf_sl, rf_sl_args)) {
      fprintf(stderr, "Error opening rf\n");
      exit(-1);
    }else{
      printf("RF open with success");

    }

#else
    printf("Error RF not available. Select an output file\n");
    exit(-1);
#endif
  }

  if (net_port > 0) {
    if (srslte_netsource_init(&net_source, "0.0.0.0", net_port, SRSLTE_NETSOURCE_TCP)) {
      fprintf(stderr, "Error creating input UDP socket at port %d\n", net_port);
      exit(-1);
    }
    if (null_file_sink) {
      if (srslte_netsink_init(&net_sink_sl, "127.0.0.1", net_port+1, SRSLTE_NETSINK_TCP)) {
        fprintf(stderr, "Error sink\n");
        exit(-1);
      }
    }
    if (sem_init(&net_sem, 0, 1)) {
      perror("sem_init");
      exit(-1);
    }
  }

  /* create ifft object */
  if (srslte_ofdm_tx_init(&ifft, SRSLTE_CP_NORM, cell_sl.nof_prb)) {
    fprintf(stderr, "Error creating iFFT object\n");
    exit(-1);
  }
  srslte_ofdm_set_normalize(&ifft, true);
  if (srslte_pbch_init(&pbch, cell_sl)) {
    fprintf(stderr, "Error creating PBCH object\n");
    exit(-1);
  }

  if (srslte_regs_init(&regs, cell_sl)) {
    fprintf(stderr, "Error initiating regs\n");
    exit(-1);
  }

  if (srslte_pcfich_init(&pcfich, &regs, cell_sl)) {
    fprintf(stderr, "Error creating PBCH object\n");
    exit(-1);
  }

  if (srslte_regs_set_cfi(&regs, cfi)) {
    fprintf(stderr, "Error setting CFI\n");
    exit(-1);
  }

  if (srslte_pdcch_init(&pdcch, &regs, cell_sl)) {
    fprintf(stderr, "Error creating PDCCH object\n");
    exit(-1);
  }

  if (srslte_pssch_init(&pssch, cell_sl)) {
    fprintf(stderr, "Error creating PSSCH object\n");
    exit(-1);
  }

  srslte_pssch_set_rnti(&pssch, UE_CRNTI);

///////Yi: added PSSCH, for PUSCH encoder setting rnti
 // srslte_pusch_set_rnti(&pusch, UE_CRNTI);
/////////////////
  if (srslte_softbuffer_tx_init(&softbuffer, cell_sl.nof_prb)) {
    fprintf(stderr, "Error initiating soft buffer\n");
    exit(-1);
  }
}

void base_free() {

  srslte_softbuffer_tx_free(&softbuffer);
  srslte_pssch_free(&pssch);
  srslte_pdcch_free(&pdcch);
  srslte_regs_free(&regs);
  srslte_pbch_free(&pbch);

  srslte_ofdm_tx_free(&ifft);

  if (sf_buffer_sl) {
    free(sf_buffer_sl);
  }
  if (output_buffer) {
    free(output_buffer);
  }
  if (output_file_name) {
    if (!null_file_sink) {
      srslte_filesink_free(&fsink);
    }
  } else {
#ifndef DISABLE_RF
    srslte_rf_close(&rf_sl);

#endif
  }

  if (net_port > 0) {
    srslte_netsource_free(&net_source);
    sem_close(&net_sem);
  }
}





unsigned int
reverse(register unsigned int x)
{
    x = (((x & 0xaaaaaaaa) >> 1) | ((x & 0x55555555) << 1));
    x = (((x & 0xcccccccc) >> 2) | ((x & 0x33333333) << 2));
    x = (((x & 0xf0f0f0f0) >> 4) | ((x & 0x0f0f0f0f) << 4));
    x = (((x & 0xff00ff00) >> 8) | ((x & 0x00ff00ff) << 8));
    return((x >> 16) | (x << 16));

}

uint32_t prbset_to_bitmask() {
  uint32_t mask=0;
  int nb = (int) ceilf((float) cell_sl.nof_prb / srslte_ra_type0_P(cell_sl.nof_prb));
  for (int i=0;i<nb;i++) {
    if (i >= prbset_orig && i < prbset_orig + prbset_num) {
      mask = mask | (0x1<<i);
    }
  }
  return reverse(mask)>>(32-nb);
}

int update_radl() {

  bzero(&ra_dl, sizeof(srslte_ra_dl_dci_t));
  ra_dl.harq_process = 0;
  ra_dl.mcs_idx = mcs_idx;
  ra_dl.ndi = 0;
  ra_dl.rv_idx = 0;
  ra_dl.alloc_type = SRSLTE_RA_ALLOC_TYPE0;
  ra_dl.type0_alloc.rbg_bitmask = prbset_to_bitmask();

  srslte_ra_pdsch_fprint(stdout, &ra_dl, cell_sl.nof_prb);
  srslte_ra_dl_grant_t dummy_grant;
  srslte_ra_nbits_t dummy_nbits;
  srslte_ra_dl_dci_to_grant(&ra_dl, cell_sl.nof_prb, UE_CRNTI, &dummy_grant);
  srslte_ra_dl_grant_to_nbits(&dummy_grant, cfi, cell_sl, 0, &dummy_nbits);
  srslte_ra_dl_grant_fprint(stdout, &dummy_grant);
  printf("Type new MCS index and press Enter: "); fflush(stdout);

  return 0;
}

/* Read new MCS from stdin */
int update_control() {
  char input[128];

  fd_set set;
  FD_ZERO(&set);
  FD_SET(0, &set);

  struct timeval to;
  to.tv_sec = 0;
  to.tv_usec = 0;

  int n = select(1, &set, NULL, NULL, &to);
  if (n == 1) {
    // stdin ready
    if (fgets(input, sizeof(input), stdin)) {
      if(input[0] == 27) {
        switch(input[2]) {
          case RIGHT_KEY:
            if (prbset_orig  + prbset_num < (int) ceilf((float) cell_sl.nof_prb / srslte_ra_type0_P(cell_sl.nof_prb)))
              prbset_orig++;
            break;
          case LEFT_KEY:
            if (prbset_orig > 0)
              prbset_orig--;
            break;
          case UP_KEY:
            if (prbset_num < (int) ceilf((float) cell_sl.nof_prb / srslte_ra_type0_P(cell_sl.nof_prb)))
              prbset_num++;
            break;
          case DOWN_KEY:
            last_prbset_num = prbset_num;
            if (prbset_num > 0)
              prbset_num--;
            break;
        }
      } else {
        last_mcs_idx = mcs_idx;
        mcs_idx = atoi(input);
      }
      bzero(input,sizeof(input));
      if (update_radl()) {
        printf("Trying with last known MCS index\n");
        mcs_idx = last_mcs_idx;
        prbset_num = last_prbset_num;
        return update_radl();
      }
    }
    return 0;
  } else if (n < 0) {
    // error
    perror("select");
    return -1;
  } else {
    return 0;
  }
}


/** Function run in a separate thread to receive UDP data */
void *net_thread_fnc(void *arg) {
  int n;
  int rpm = 0, wpm=0;

  do {
    n = srslte_netsource_read(&net_source, &data2[rpm], DATA_BUFF_SZ-rpm);
    if (n > 0) {
      int nbytes = 1+(pssch_cfg.grant.mcs.tbs-1)/8;
      rpm += n;
      INFO("received %d bytes. rpm=%d/%d\n",n,rpm,nbytes);
      wpm = 0;
      while (rpm >= nbytes) {
        // wait for packet to be transmitted
        sem_wait(&net_sem);
        memcpy(data_sl, &data2[wpm], nbytes);
        INFO("Sent %d/%d bytes ready\n", nbytes, rpm);
        rpm -= nbytes;
        wpm += nbytes;
        net_packet_ready = true;
      }
      if (wpm > 0) {
        INFO("%d bytes left in buffer for next packet\n", rpm);
        memcpy(data2, &data2[wpm], rpm * sizeof(uint8_t));
      }
    } else if (n == 0) {
      rpm = 0;
    } else {
      fprintf(stderr, "Error receiving from network\n");
      exit(-1);
    }
  } while(n >= 0);
  return NULL;
}


int main(int argc, char **argv) {

  pthread_t thread_downlink;
  pthread_t thread_sidelink;
  pthread_t socketThread;
  pthread_t socketThread_sl;
  parse_args(&prog_args, argc, argv);
  //parse_args(argc, argv);not needed
  if (portnumber){
    if(pthread_create( &socketThread, NULL , socket_thread_fctn, NULL)){
      printf("Error - pthread_create()");
      exit(EXIT_FAILURE);
    }
  }

if(portnumber_sl){
    if(pthread_create( &socketThread_sl, NULL , socket_thread_fctn_sl, NULL)){
     printf("Error - pthread_create()");
     exit(EXIT_FAILURE);
    }
  }

printf ("before going into thread\n");
  //pthread_create( &thread_downlink, NULL , (void *)loop_downlink, NULL);
 // pthread_create( &thread_sidelink, NULL , (void *)loop, NULL);
  //pthread_join(thread_downlink,NULL);
 // pthread_join(thread_sidelink,NULL);
loop_downlink();
printf ("after going into thread\n");

  //ROBSON: moved to the end of program
  #ifndef DISABLE_GRAPHICS
  if (!prog_args.disable_plots) {
  if (!pthread_kill(plot_thread, 0)) {
      pthread_kill(plot_thread, SIGHUP);
      pthread_join(plot_thread, NULL);
  }
  }
  #endif

#ifdef DISABLE_RF
  if (argc < 3) {
    usage(argv[0]);
    exit(-1);
  }
#endif
 
  printf("\nBye\n");
  exit(0);
  //printf("Done\n");not needed
  //exit(0);not needed
}


/**********************************************************************
 *  Plotting Functions
 ***********************************************************************/
#ifndef DISABLE_GRAPHICS


plot_real_t p_sync, pce;
plot_scatter_t  pscatequal, pscatequal_pdcch;

float tmp_plot[110*15*2048];
float tmp_plot2[110*15*2048];
float tmp_plot3[110*15*2048];
void *plot_thread_run(void *arg) {
  int oldstate, oldtype;
  pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, &oldstate);
  pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, &oldtype);
  int i;
  uint32_t nof_re = SRSLTE_SF_LEN_RE(ue_dl.cell.nof_prb, ue_dl.cell.cp);
  sdrgui_init();



 plot_scatter_init(&pscatequal);
 plot_scatter_setTitle(&pscatequal, "PDSCH - Equalized Symbols");
 plot_scatter_setXAxisScale(&pscatequal, -4, 4);
 plot_scatter_setYAxisScale(&pscatequal, -4, 4);
 plot_scatter_addToWindowGrid(&pscatequal, (char*)"pdsch_ue", 0, 0);



  if (!prog_args.disable_plots_except_constellation) {
    plot_real_init(&pce);
    plot_real_setTitle(&pce, "Channel Response - Magnitude");
    plot_real_setLabels(&pce, "Index", "dB");
    plot_real_setYAxisScale(&pce, -40, 40);


    plot_real_init(&p_sync);
    plot_real_setTitle(&p_sync, "PSS Cross-Corr abs value");
    plot_real_setYAxisScale(&p_sync, 0, 1);

    plot_scatter_init(&pscatequal_pdcch);
    plot_scatter_setTitle(&pscatequal_pdcch, "PDCCH - Equalized Symbols");
    plot_scatter_setXAxisScale(&pscatequal_pdcch, -4, 4);
    plot_scatter_setYAxisScale(&pscatequal_pdcch, -4, 4);

    plot_real_addToWindowGrid(&pce, (char*)"pdsch_ue",    0, 1);
    plot_real_addToWindowGrid(&pscatequal_pdcch,  (char*)"pdsch_ue", 1, 0);
    plot_real_addToWindowGrid(&p_sync, (char*)"pdsch_ue", 1, 1);
 }
  while(1) {
    sem_wait(&plot_sem);
    uint32_t nof_symbols = ue_dl.pdsch_cfg.nbits.nof_re;
    if (!prog_args.disable_plots_except_constellation) {
      for (i = 0; i < nof_re; i++) {
        tmp_plot[i] = 20 * log10f(cabsf(ue_dl.sf_symbols[i]));
        if (isinf(tmp_plot[i])) {
          tmp_plot[i] = -80;
        }
      }

     int sz = srslte_symbol_sz(ue_dl.cell.nof_prb);
     bzero(tmp_plot2, sizeof(float)*sz);
     int g = (sz - 12*ue_dl.cell.nof_prb)/2;
      for (i = 0; i < 12*ue_dl.cell.nof_prb; i++) {
        tmp_plot2[g+i] = 20 * log10(cabs(ue_dl.ce[0][i]));
      if (isinf(tmp_plot2[g+i])) {
          tmp_plot2[g+i] = -80;
        }
      }

      plot_real_setNewData(&pce, tmp_plot2, sz);

      if (!prog_args.input_file_name) {
        if (plot_track) {
          srslte_pss_synch_t *pss_obj = srslte_sync_get_cur_pss_obj(&ue_sync.strack);
          int max = srslte_vec_max_fi(pss_obj->conv_output_avg, pss_obj->frame_size+pss_obj->fft_size-1);
          srslte_vec_sc_prod_fff(pss_obj->conv_output_avg,
                          1/pss_obj->conv_output_avg[max],
                          tmp_plot2,
                          pss_obj->frame_size+pss_obj->fft_size-1);
          plot_real_setNewData(&p_sync, tmp_plot2, pss_obj->frame_size);
        } else {
          int max = srslte_vec_max_fi(ue_sync.sfind.pss.conv_output_avg, ue_sync.sfind.pss.frame_size+ue_sync.sfind.pss.fft_size-1);
          srslte_vec_sc_prod_fff(ue_sync.sfind.pss.conv_output_avg,
                          1/ue_sync.sfind.pss.conv_output_avg[max],
                          tmp_plot2,
                          ue_sync.sfind.pss.frame_size+ue_sync.sfind.pss.fft_size-1);
          plot_real_setNewData(&p_sync, tmp_plot2, ue_sync.sfind.pss.frame_size);
        }

      }

      plot_scatter_setNewData(&pscatequal_pdcch, ue_dl.pdcch.d, 36*ue_dl.pdcch.nof_cce);
    }

    plot_scatter_setNewData(&pscatequal, ue_dl.pdsch.d, nof_symbols);

    if (plot_sf_idx == 1) {
      if (prog_args.net_port_signal > 0) {
        srslte_netsink_write(&net_sink_signal, &sf_buffer[srslte_ue_sync_sf_len(&ue_sync)/7],
                            srslte_ue_sync_sf_len(&ue_sync));
      }
    }

  }

  return NULL;
}

void init_plots() {

  if (sem_init(&plot_sem, 0, 0)) {
    perror("sem_init");
    exit(-1);
  }

  pthread_attr_t attr;
  struct sched_param param;
  param.sched_priority = 0;
  pthread_attr_init(&attr);
  pthread_attr_setschedpolicy(&attr, SCHED_OTHER);
  pthread_attr_setschedparam(&attr, &param);
  //ROBSON: old create function did not make use of attr
  if (pthread_create(&plot_thread, &attr, plot_thread_run, NULL)) {
    perror("pthread_create");
    exit(-1);
  }
}

#endif
