#include<stdio.h>
#include<stdlib.h>
#include<gtk/gtk.h>
//file for socket implementation
#include"client.h"

GtkBuilder *builder;
GObject *window;
//sidelink
GObject *restartButton_sl;
GtkSpinButton *spinButton_sl;
GtkEntry *gainText_sl;
GObject *prbText_sl;
GObject *ampText;
GObject *MCSText;
GtkRadioButton *ghzRadio_sl;
GtkRadioButton *mhzRadio_sl;
GList *radioGroup_sl;
//socket objects for sidelink
GObject *portText_sl;
GObject *connectButton_sl;

//functions for sidelink

static void restart_sl(GtkWidget *widget,gpointer data){
  char socket_data[100];
  printf("\nrestarting\n");
  //print formatted output to array
  sprintf(socket_data,"restart:%d\0",1);
  //send array through socket
  socket_send(socket_data);
 }

static void open_port_sl(GtkWidget *widget, gpointer textEntry){
  char socket_data[100];
  int port=atoi(gtk_entry_get_text(textEntry));
  printf("\nOpening port %d\n",port);
  client_init(port);
}

static void toggl_sl(GtkRadioButton *widget, int* data){
  GtkAdjustment *adjustment;
  //Checks which radio button was pressed (GHz or MHz)
  if(gtk_toggle_button_get_active (widget)){
    *data = 1000000000;
    printf("frequency_multiplier=%d\n",*data);
    adjustment = gtk_spin_button_get_adjustment (spinButton_sl);
    float value=200;
    value = (float)gtk_adjustment_get_value (adjustment);
    gtk_adjustment_configure (adjustment,value/1000,0,8,0.1,0,1);
    gtk_spin_button_set_adjustment (spinButton_sl, adjustment);
  }else{
    *data = 1000000;
    printf("frequency_multiplier=%d\n",*data);
    adjustment = gtk_spin_button_get_adjustment (spinButton_sl);
    float value=200;
    value = (float)gtk_adjustment_get_value (adjustment);
    gtk_adjustment_configure (adjustment,value*1000,0,8000,1000,0,1);
    gtk_spin_button_set_adjustment (spinButton_sl, adjustment);
  }
}

static void changeFrequency_sl(GtkSpinButton *spin_button, int *  data){
  //adjustment to retrive the value from spin button
  GtkAdjustment *adjustment;
  //get adjustment object from spin button
  adjustment = gtk_spin_button_get_adjustment (spin_button);
  float value=200;
  value = (float)gtk_adjustment_get_value (adjustment);
  //multiply the value from spin button with the base 10^6 or 10^9
  value=value*(*data);
  char socket_data[100];
  sprintf(socket_data,"frequency:%.2f\0",value);
  socket_send(socket_data);
  printf("Frequency changed, the USRP will be restarted\n");
}

static void set_gain_sl(GtkEntry *obj, gpointer entry){
  int gain=atoi(gtk_entry_get_text(obj));
  char socket_data[100];
  printf("\nChange in gain to %d requested\n",gain);
  sprintf(socket_data,"gain:%d\0",gain);
  socket_send(socket_data);
}

static void gtk_set_prbs_sl(GtkWidget *obj, gpointer entry){
  int nof_prbs=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange in number of PRBs requested %d\n",nof_prbs);
  sprintf(socket_data,"prbs:%d\0",nof_prbs);
  socket_send(socket_data);
}

static void gtk_set_new_MCS(GtkWidget *obj, gpointer  entry){
  int id=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange of MCS requested %d\n",id);
  sprintf(socket_data,"mcs:%d\0",id);
  socket_send(socket_data);
}

static void gtk_set_amp(GtkWidget *obj, gpointer  entry){
  int amp = atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  socket_send(socket_data);
  sprintf(socket_data,"amp:%d\0",amp);
}


void main(int argc, char *argv[]){
//freq multiplier 10^6 or 10^9
int frequency_multiplier=1000000000;

//inits gtk, program arguments could be passed instead of NULL
gtk_init (NULL, NULL);
//builder for importing buttons and other widgets from .ui file
builder = gtk_builder_new ();
//opens the gtkbuilder file created with glade
gtk_builder_add_from_file (builder, "ue_relay_gui_sl.ui", NULL);
//window
window = gtk_builder_get_object (builder, "window1");
//g_signal_connect links a signal to a handler function
g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);


//creates spinbutton object for sidelink
spinButton_sl = gtk_builder_get_object (builder, "spinbutton2");
//sets initial value, limits and step for the spinbutton
GtkAdjustment *adj_sl = gtk_adjustment_new (2.400, 0,8, 0.01, 0, 1);
gtk_spin_button_set_adjustment (spinButton_sl, adj_sl);
g_signal_connect(spinButton_sl,"value-changed",G_CALLBACK(changeFrequency_sl),&frequency_multiplier);

//text entry object for sidelink
gainText_sl = GTK_WIDGET(gtk_builder_get_object(builder,"entry6"));
g_signal_connect (gainText_sl, "activate", G_CALLBACK (set_gain_sl), gainText_sl);

//text entry object for sidelink
prbText_sl = gtk_builder_get_object(builder,"entry7");
g_signal_connect(prbText_sl,"activate",G_CALLBACK(gtk_set_prbs_sl),prbText_sl);

//text entry object for sidelink
ampText=gtk_builder_get_object(builder,"entry9");
g_signal_connect(ampText,"activate",G_CALLBACK(gtk_set_amp),ampText);

//text entry object for sidelink
MCSText=gtk_builder_get_object(builder,"entry8");
g_signal_connect(MCSText,"activate",G_CALLBACK(gtk_set_new_MCS),MCSText);


//radiobutton group, for GHz or MHz selection object for sidelink
mhzRadio_sl = gtk_builder_get_object(builder,"radiobutton4");
ghzRadio_sl = gtk_builder_get_object(builder,"radiobutton3");
//starts with GHz set active
gtk_toggle_button_set_active (ghzRadio_sl,TRUE);
radioGroup_sl = gtk_radio_button_get_group (ghzRadio_sl);
gtk_radio_button_set_group (mhzRadio_sl,radioGroup_sl);
g_signal_connect(ghzRadio_sl,"toggled",G_CALLBACK(toggl_sl),&frequency_multiplier);

//restart button object for sidelink
restartButton_sl = gtk_builder_get_object(builder,"button4");
g_signal_connect(restartButton_sl,"clicked",G_CALLBACK(restart_sl),NULL);

//text entry object for port for sidelink
portText_sl = gtk_builder_get_object(builder,"entry10");
//socket opening button object for sidelink
connectButton_sl = gtk_builder_get_object(builder,"button3");
g_signal_connect(connectButton_sl,"clicked",G_CALLBACK(open_port_sl),portText_sl);

gtk_main ();
}
