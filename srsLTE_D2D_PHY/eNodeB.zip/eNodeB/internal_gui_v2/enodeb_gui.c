#include<stdio.h>
#include<stdlib.h>
#include<gtk/gtk.h>
//file for socket implementation
#include"client.h"

//widgets declarations
GtkBuilder *builder;
GObject *window;
GObject *button;
GtkSpinButton *spinButton;
GtkEntry *gainText;
GObject *prbText;
GObject *ampText;
GObject *cellIDText;
GObject *MCSText;
GtkRadioButton *ghzRadio;
GtkRadioButton *mhzRadio;
GList *radioGroup;
//widgets for socket port input
GObject *portText;
GObject *connectButton;
//Event functions. These functions simply put the parameters
//input by user in the socket
static void open_port(GtkWidget *widget, gpointer textEntry){
  char socket_data[100];
  int port=atoi(gtk_entry_get_text(textEntry));
  printf("\nOpening port %d\n",port);
  client_init(port);
}
static void restart(GtkWidget *widget,gpointer   data){
  char socket_data[100];
  printf("\nrestarting\n");
  //print formatted output to array
  sprintf(socket_data,"restart:%d\0",1);
  //send array through socket
  socket_send(socket_data);
 }
static void  toggl(GtkRadioButton *widget, int * data){
  GtkAdjustment *adjustment;
  //Checks which radio button was pressed (GHz or MHz)
  if(gtk_toggle_button_get_active (widget)){
    *data = 1000000000;
    printf("frequency_multiplier=%d\n",*data );
    adjustment = gtk_spin_button_get_adjustment (spinButton);
    float value=200;
    value = (float)gtk_adjustment_get_value (adjustment);
    gtk_adjustment_configure (adjustment,value/1000,0,8,0.1,0,1);
    gtk_spin_button_set_adjustment (spinButton, adjustment);
  }else{
    *data = 1000000;
    printf("frequency_multiplier=%d\n",*data );
    adjustment = gtk_spin_button_get_adjustment (spinButton);
    float value=200;
    value = (float)gtk_adjustment_get_value (adjustment);
    gtk_adjustment_configure (adjustment,value*1000,0,8000,1000,0,1);
    gtk_spin_button_set_adjustment (spinButton, adjustment);
  }
}
static void  set_gain(GtkEntry *obj, gpointer  entry){
  int gain=atoi(gtk_entry_get_text(obj));
  char socket_data[100];
  printf("\nChange in gain to %d requested\n",gain);
  sprintf(socket_data,"gain:%d\0",gain);
  socket_send(socket_data);
}
static void  gtk_set_prbs(GtkWidget *obj, gpointer  entry){
  int nof_prbs=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange in number of PRBs requested %d\n",nof_prbs);
  sprintf(socket_data,"prbs:%d\0",nof_prbs);
  socket_send(socket_data);
}
static void  gtk_set_amp(GtkWidget *obj, gpointer  entry){
  int amp = atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  socket_send(socket_data);
  sprintf(socket_data,"amp:%d\0",amp);
}

static void  gtk_set_new_cell_ID(GtkWidget *obj, gpointer  entry){
  int id=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange of cell ID requested %d\n",id);
  sprintf(socket_data,"cell:%d\0",id);
  socket_send(socket_data);
}

static void  gtk_set_new_MCS(GtkWidget *obj, gpointer  entry){
  int id=atoi(gtk_entry_get_text(entry));
  char socket_data[100];
  printf("\nChange of MCS requested %d\n",id);
  sprintf(socket_data,"mcs:%d\0",id);
  socket_send(socket_data);
}
//
static void  changeFrequency(GtkSpinButton *spin_button , int *   data){
  //adjustment to retrive the value from spin button
  GtkAdjustment *adjustment;
  //get adjustment object from spin button
  adjustment = gtk_spin_button_get_adjustment (spin_button);
  float value=200;
  value = (float)gtk_adjustment_get_value (adjustment);
  //multiply the value from spin button with the base 10^6 or 10^9
  value=value*(*data);
  char socket_data[100];
  sprintf(socket_data,"frequency:%.2f\0",value);
  socket_send(socket_data);
  printf("Frequency changed, the USRP will be restarted\n");
}

void main(int argc, char *argv[]){

  //freq multiplier 10^6 or 10^9, starts in GHz
  int frequency_multiplier=1000000000;

  //inits gtk, program arguments could be passed instead of NULL
  gtk_init (NULL, NULL);
  //builder for importing buttons and other widgets from .ui file
  builder = gtk_builder_new ();
  //opens the gtkbuilder file created with glade
  gtk_builder_add_from_file (builder, "enodeb_gui.ui", NULL);

  //window
  window = gtk_builder_get_object (builder, "window");
  //g_signal_connect links a signal to a handler function
  g_signal_connect (window, "destroy", G_CALLBACK (gtk_main_quit), NULL);

  //creates spinbutton object
  spinButton=gtk_builder_get_object (builder, "freqSpinbutton");
  //sets initial value, limits and step for the spinbutton
  GtkAdjustment *adj = gtk_adjustment_new (0, 0,8, 0.01, 0, 1);gtk_spin_button_set_adjustment (spinButton, adj);
  g_signal_connect(spinButton,"value-changed",G_CALLBACK(changeFrequency),&frequency_multiplier);


  //text entry
  gainText=GTK_WIDGET(gtk_builder_get_object(builder,"gainEntry"));
  g_signal_connect (gainText, "activate", G_CALLBACK (set_gain), gainText);
  //text entr
  prbText=gtk_builder_get_object(builder,"prbsEntry");
  g_signal_connect(prbText,"activate",G_CALLBACK(gtk_set_prbs),prbText);
  //text entry
  ampText=gtk_builder_get_object(builder,"ampEntry");
  g_signal_connect(ampText,"activate",G_CALLBACK(gtk_set_amp),ampText);
  //text entry
  cellIDText=gtk_builder_get_object(builder,"cellEntry");
  g_signal_connect(cellIDText,"activate",G_CALLBACK(gtk_set_new_cell_ID),cellIDText);
  MCSText=gtk_builder_get_object(builder,"mcsEntry");
  g_signal_connect(MCSText,"activate",G_CALLBACK(gtk_set_new_MCS),MCSText);

  //radiobutton group, for GHz or MHz selection
  mhzRadio=gtk_builder_get_object(builder,"radiobutton2");
  ghzRadio=gtk_builder_get_object(builder,"radiobutton1");
  //starts with GHz set active
  gtk_toggle_button_set_active (ghzRadio,TRUE);
  radioGroup = gtk_radio_button_get_group (ghzRadio);
  gtk_radio_button_set_group (mhzRadio,radioGroup);
  g_signal_connect(ghzRadio,"toggled",G_CALLBACK(toggl),&frequency_multiplier);

  //restart button
  button=gtk_builder_get_object(builder,"button1");
  g_signal_connect(button,"clicked",G_CALLBACK(restart),NULL);

  portText=gtk_builder_get_object(builder,"entry5");
  //socket opening button
  connectButton=gtk_builder_get_object(builder,"button2");
  g_signal_connect(connectButton,"clicked",G_CALLBACK(open_port),portText);

  gtk_main ();

}
