#ifndef SERVER_H
#define SERVER_H
//ROBSON: Functions' declarations
void error(const char *msg);
extern void server_init(int port);
extern char* socket_read(char * buff);
extern void socket_write(char * buff);
extern void socket_close();
#endif
